<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Sikka Kaamya Greens 1695 SQ.FT. 4BHK + Servant Flat for Sale</title>
<meta name="description" itemprop="description" content="Sikka Kaamya Greens offering Specious 4BHK with Servant Flat for Sale (1695 SQ.FT.) in Sector-10, Noida Extension. Call-9899424270 or Register for Best Deal." />
<meta name="keywords" itemprop="keywords" content="sikka kaamya greens, sikka kaamya greens noida extension, sikka kaamya greens greater noida west, sikka kaamya greens floor plan, sikka kaamya greens site map, sikka kaamya greens price list, sikka kaamya greens location map, sikka kaamya greens brochure, sikka group" />
<link rel="canonical" href="https://www.sikkakaamyagreens.in/1695-4bhk-servant-flat-for-sale.php" />

<meta name="google-site-verification" content="ZNaOKd1zQusxwr9Kwj9CUwbCW4fVfIbfpc7IUstvquM" />
<meta name="revisit-after" content="1 days" />
<meta name="distribution" content="Global" />
<meta name="Language" content="English" />
<meta name="doc-type" content="Public" />
<meta name="robots" content="index, follow" />
<meta name="author" content="Sikka Kaamya Greens" />
<meta name="title" content="Sikka Kaamya Greens">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="category" content="buy, rent, sell, residential, commercial, brokers, dealers, pg, house, real estate agents, flats, apartments, house, plots, home, shop, office, complex, villa, lease, property delhi ncr, real estate, delhi/ncr, gurgaon, greater-noida, ghaziabad, lucknow" />
<meta name="alexa" content="100" /><meta name="googlebot" content="all, index, follow" /><meta name="YahooSeeker" content="all, index, follow" /><meta name="msnbot" content="all, index, follow" /><meta name="pagerank" content="10" /><meta name="serps" content="1, 2, 3, 10, 11, 12, 13, 20, ATF" /><meta name="relevance" content="high" />
<!-- Favicon  -->
<link rel="icon" href="img/images/favicon.png">
<!-- Style CSS -->
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.css">
<!-- ValidateForm bellow -->
<script type="text/javascript" src="js/validation.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<!--	control u,c & right click disable start	-->

<!--	control u,c & right click disable end	-->

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/62fa0dfa37898912e9630eb5/1gagcd7ol';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->


</head>

<body>
    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="h-100 d-md-flex justify-content-between align-items-center">
                <div class="email-address">
                    Welcome to Sikka Kaamya Greens Sector-10 Greater Noida(W).
                </div>
                <div class="phone-number d-flex">
                    <div class="icon">
                        <i class="fa fa-volume-control-phone"></i>
                    </div>
                    <div class="number">
                        <a href="tel:+91-9899424270">+91-9899424270</a>                    </div>
                </div>
            </div>
        </div>
        <!-- Main Header Area -->
        <div class="main-header-area" id="stickyHeader">
            <div class="classy-nav-container breakpoint-off">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="southNav">
					<!-- Logo -->
                    <a class="nav-brand" href="./"><img src="img/images/logo-sikka.jpeg" alt="sikka logo" title="sikka group" class="img-responsive" width="131px;"></a>

                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">

                        <!-- close btn -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>

                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul>
                                <li><a href="./">Home</a></li>
                                <li><a href="#About">About</a></li>
                                <li><a href="#Gallery">Gallery</a></li>
                                <li><a href="#Floor">Floor Plan</a></li>
                                <li><a href="#SiteMap">Site Map</a></li>
                                <li><a href="#Location">Location</a></li>
                                <li><a href="#Register">Register</a></li>
                                <li><a href="brochure.php">Brochure</a></li>
                                <li><a href="our-address.php">Contact</a></li>
                            </ul>

                            <!-- Search Form -->
                           <!-- Search Button -->
                            
                        </div>
                        <!-- Nav End -->
                    </div>
                    <a class="nav-brand" href="./"><img src="img/images/sikka-kaamya-greens-logo.jpeg" alt="sikka kaamya greens logo" title="sikka kaamya greens greater noida west" class="img-responsive" width="131px;" style="margin-left:30px;"></a>
                </nav>
            </div>
        </div>    </header>
    <!-- ##### Header Area End ##### -->
	
    <!-- ##### Main Banner Start ##### -->
    <section section="container">
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
    
          <div class="item active">
            <img src="img/images/banner.jpeg" alt="banner" style="width:100%;">            <div class="centered">4 BHK + Servant</div>
          </div>
    
        </div>
    
        <!-- Left and right controls -->
      </div>
	</section>
    <!-- ##### Main Banner End ##### -->

    <!-- ##### Advance Search Area Start ##### -->
    <div class="south-search-area">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="advanced-search-form">
                        <!-- Search Title -->
                        <div class="search-title">
                            <p>Register For Site visit</p>
                        </div>
                        <!-- Search Form -->
                        <form action="mail.php" name="enquiry" id="frmcontact"  method="post" onsubmit="return validateform(this);">
                            <div class="row">

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                    	<input type="text" class="form-control" name="name" value="" placeholder="Name">
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="email" value="" placeholder="Email">
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" value="" placeholder="Phone Number">
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="message" value="" placeholder="Requirement ">
                                    </div>
                                </div>

                                <div class="col-12 d-flex justify-content-between align-items-end">
                                    <!-- More Filter -->
                                    <div class="more-filter">
                                        
                                    </div>
                                    <!-- Submit -->
                                    <div class="form-group mb-0">
                                        <button type="submit" name="submit" class="south-btn">I am Interested</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>    <!-- ##### Advance Search Area End ##### -->
    
    <!-- ##### About Project Start ##### -->
    <section class="featured-properties-area section-padding-100-25" id="About">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp">
                        <h1>Sikka Kaamya Greens 1695 SQ.FT. 4 BHK with Servant Flat for Sale in Noida Extension.</h1>
                        <div class="contant">
                            
                        </div>    
                    </div>
                </div>
	<!-- ##### Price Area Start ##### -->
    <div class="col-md-12 priceBox">
    	<div class="priceTph"><h2>Sikka Kaamya Greens Price List and Floor Plan.</h2></div>
        <div class="col-12 inrBox clearfix">
        	<div class="boxA">type</div>
            <div class="boxA">build-up area</div>
            <div class="boxA">price list(Approx)</div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="890-2bhk-flat-for-sale.php">2 BHK + 2T</a></div>
            <div class="boxB">890 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="990-2bhk-flat-for-sale.php">2 BHK + 2T</a></div>
            <div class="boxB">990 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1090-2bhk-flat-for-sale.php">2 BHK + 2T</a></div>
            <div class="boxB">1090 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1100-2bhk-study-flat-for-sale.php">2 BHK + Study</a></div>
            <div class="boxB">1100 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1250-3bhk-flat-for-sale.php">3 BHK + 2T</a></div>
            <div class="boxB">1250 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1315-3bhk-flat-for-sale.php">3 BHK + 2T</a></div>
            <div class="boxB">1315 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1450-3bhk-servant-flat-for-sale.php">3 BHK + Servant</a></div>
            <div class="boxB">1450 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1650-3bhk-servant-flat-for-sale.php">3 BHK + Servant</a></div>
            <div class="boxB">1650 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="1695-4bhk-servant-flat-for-sale.php">4 BHK + Servant</a></div>
            <div class="boxB">1695 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        <div class="col-12 inrBox2 clearfix">
        	<div class="boxB"><a href="2150-4bhk-servant-flat-for-sale.php">4 BHK + Servant</a></div>
            <div class="boxB">2150 SQ.FT.</div>
            <div class="boxB"><a href="javascript:void(0)" data-toggle="modal" data-target="#Enquire_Now_Popup">Enquire Now</a></div>
        </div>
        
    </div>    <!-- ##### Price Area End ##### -->
            </div>
		
        </div>
    </section>
    <!-- ##### About Project End ##### -->
    
    <!-- ##### Features and Amenities Area Start ##### -->
    <section class="featured-properties-area section-padding-50-25 boxBg1" id="Features">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp">
                        <h2>Amenities</h2>
                        <ul class="featuresBox">
                        	<li><img src="./img/icons_resi/prime_location.png"><p>Prime Pocation</p></li>
                            <li><img src="./img/icons_resi/lift.png"><p>Lift</p></li>
                            <li><img src="./img/icons_resi/fire_fighting.png"><p>Fire Fighting</p></li>
                            <li><img src="./img/icons_resi/intercom.png"><p>InterCom</p></li>
                            <li><img src="./img/icons_resi/parking.png"><p>Car Parking</p></li>
                            <li><img src="./img/icons_resi/landscape-garden.png"><p>Landscape Garden</p></li>
                            <li><img src="./img/icons_resi/jogging-track.png"><p>Jogging Track</p></li>
                            <li><img src="./img/icons_resi/reflexology-park.png"><p>Reflexology Park</p></li>
                            <li><img src="./img/icons_resi/yoga.png"><p>Yoga/Meditation Area</p></li>
                            <li><img src="./img/icons_resi/ro.png"><p>RO</p></li>
                            <li><img src="./img/icons_resi/temple.png"><p>Temple</p></li>
                            <li><img src="./img/icons_resi/school.png"><p>School</p></li>
                            <li><img src="./img/icons_resi/club_house.png"><p>Club House</p></li>
                            <li><img src="./img/icons_resi/play_zone.png"><p>Kids Play Zone</p></li>
                            <li><img src="./img/icons_resi/gymnasium.png"><p>Gymnasium</p></li>
                            <li><img src="./img/icons_resi/badminton_court.png"><p>Badminton Court</p></li>
                            <li><img src="./img/icons_resi/basketball_court.png"><p>Basketball Court</p></li>
                            <li><img src="./img/icons_resi/table_tennis.png"><p>Table Tennis</p></li>
                            <li><img src="./img/icons_resi/pool_table.png"><p>Pool Table</p></li>
                            <li><img src="./img/icons_resi/carrom.png"><p>Carrom</p></li>
                            <li><img src="./img/icons_resi/skating_rink.png"><p>Skating Rink</p></li>
                            <li><img src="./img/icons_resi/cricket_pitch.png"><p>Cricket Pitch</p></li>
                            <li><img src="./img/icons_resi/swimming_pool.png"><p>Swimming Pool</p></li>
                            <li><img src="./img/icons_resi/amphitheatre.png"><p>Amphitheatre</p></li>
                            <li><img src="./img/icons_resi/24_hr_security.png"><p>24 HR Security</p></li>
                            <li><img src="./img/icons_resi/hi_tech_security.png"><p>Hi-Tech Security</p></li>
                            <li><img src="./img/icons_resi/power_backup.png"><p>Power Backup</p></li>
                        </ul>
                    </div>
                </div>
            </div>
		
        </div>
</section>    <!-- ##### Features and Amenities Area End ##### -->

    <!-- ##### Gallery Area Start ##### -->
    <section class="south-testimonials-area section-padding-100-25" id="Gallery">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp" data-wow-delay="250ms">
                        <h2>Sikka Kaamya Greens -Gallery</h2>
                    </div>
                </div>
            </div>
							<div class="row">
                <div class="col-12">
                    <div class="testimonials-slides owl-carousel wow fadeInUp" data-wow-delay="500ms">

                        <!-- Single Testimonial Slide -->
                        <div class="single-testimonial-slide text-center">
                        	<a href="img/images/gal-sikka-kaamya-greens-1.jpeg" data-fancybox="images"><img src="img/images/gal-sikka-kaamya-greens-1.jpeg" class="img-responsive" alt="gal-sikka-kaamya-greens" title="Sikka Kaamya Greens"></a>
                        </div>
						<!-- Single Testimonial Slide -->
                        <div class="single-testimonial-slide text-center">
                        	<a href="img/images/gal-sikka-kaamya-greens-2.jpeg" data-fancybox="images"><img src="img/images/gal-sikka-kaamya-greens-2.jpeg" class="img-responsive" alt="gal-sikka-kaamya-greens" title="Sikka Kaamya Greens"></a>
                        </div>
						<!-- Single Testimonial Slide -->
                        <div class="single-testimonial-slide text-center">
                        	<a href="img/images/gal-sikka-kaamya-greens-3.jpeg" data-fancybox="images"><img src="img/images/gal-sikka-kaamya-greens-3.jpeg" class="img-responsive" alt="gal-sikka-kaamya-greens" title="Sikka Kaamya Greens"></a>
                        </div>
						
                    </div>
                </div>
            </div>        </div>
    </section>
    
    <!-- ##### Gallery Area End ##### -->
    
    <!-- ##### Floor Plan Area Start ##### -->
    <section class="featured-properties-area section-padding-100-25 boxBg1" id="Floor">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp">
                        <h2>Sikka Kaamya Greens -Floor Plan</h2>
                    </div>
                </div>
            </div>
			
            <div class="row">
				<!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/890_2bhk.jpeg" data-fancybox="images"><img src="img/images/890_2bhk.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>2BHK - (890 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/990_2bhk.jpeg" data-fancybox="images"><img src="img/images/990_2bhk.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>2BHK - (990 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1090_2bhk.jpeg" data-fancybox="images"><img src="img/images/1090_2bhk.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>2BHK - (1090 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1100_2bhk_Study.jpeg" data-fancybox="images"><img src="img/images/1100_2bhk_Study.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>2BHK + Study - (1100 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1250_3bhk.jpeg" data-fancybox="images"><img src="img/images/1250_3bhk.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>3BHK - (1250 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1315_3bhk.jpeg" data-fancybox="images"><img src="img/images/1315_3bhk.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>3BHK - (1315 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1450_3bhk_Servant.jpeg" data-fancybox="images"><img src="img/images/1450_3bhk_Servant.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>3BHK + Servant - (1450 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1650_3bhk_Servant.jpeg" data-fancybox="images"><img src="img/images/1650_3bhk_Servant.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>3BHK + Servant - (1650 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/1695_4bhk_Servant.jpeg" data-fancybox="images"><img src="img/images/1695_4bhk_Servant.jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>4BHK + Servant - (1695 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
                <!-- Single Featured Property -->
                <div class="col-12 col-md-6 col-xl-4">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/2150_4bhk_Servant .jpeg" data-fancybox="images"><img src="img/images/2150_4bhk_Servant .jpeg" class="img-responsive" alt="Floor Plan"></a>
                            <h5>4BHK + Servant - (2150 SQ.FT.)</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
         </div>
        </div>
</section>    <!-- ##### Floor Plan  Area End ##### -->
    
    <!-- ##### Site Plan Area Start ##### -->
    <section class="featured-properties-area section-padding-100-25" id="SiteMap">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp">
                        <h2>Sikka Kaamya Greens -Site Plan</h2>
                    </div>
                </div>
            </div>
			
            <div class="row">
				<!-- Single Featured Property -->
                <div class="col-12 col-md-12 col-xl-12">
                    <div class="single-featured-property mb-30 wow fadeInUp" data-wow-delay="100ms">
                        <!-- Property Thumbnail -->
                        <div class="property-thumb property-content">
                            <a href="img/images/sikka-kaamya-greens-site-map.jpeg" data-fancybox="images"><img src="img/images/sikka-kaamya-greens-site-map.jpeg" class="img-responsive" alt="Site Plan" title="sikka kaamya greens site map"></a>
                            <h5>Sikka Kaamya Greens Site Map</h5>
						</div>
                        <!-- Property Content -->
                    </div>
                </div>
                
         </div>
        </div>
</section>    <!-- ##### Site Plan  Area End ##### -->
    
    <!-- ##### Location Area Start ##### -->
    <section class="featured-properties-area section-padding-100-25 boxBg1" id="Location">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section-heading wow fadeInUp">
                        <h2>Sikka Kaamya Greens -Location Map</h2>
                    </div>
                </div>
            </div>
            <div class="col-12">
            	<div class="locationArea">
                <!--Google Map Start -->
                	<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14016.082909064377!2d77.4787369!3d28.5691403!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7c4551accfcb80fd!2sSikka%20Kaamya%20Greens!5e0!3m2!1sen!2sin!4v1660363370924!5m2!1sen!2sin" width="100%" height="635" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    <!--Google Map End -->
                </div>
                <div class="locationAdv" >
                	<h2>Location Advantage</h2>
                    <ul>
                    	<li><i class="fa fa-map-marker"></i> 05 KM from Gaur Chowk.</li>
                        <li><i class="fa fa-map-marker"></i> 0.5 KM from Metro Station.</li>
                        <li><i class="fa fa-map-marker"></i> 08 KM from NH 24.</li>
                        <li><i class="fa fa-map-marker"></i> 12 KM from City Center, Noida.</li>
                        <li><i class="fa fa-map-marker"></i> 12 KM from Ghaziabad Rilway Station.</li>
                        <li><i class="fa fa-map-marker"></i> 12 KM from Fortis Hospital.</li>
                        <li><i class="fa fa-map-marker"></i> 12 KM from Sector 62 Noida.</li>
                        <li><i class="fa fa-map-marker"></i> 18 KM from GIP & DLF Mall Sec-18 Noida.</li>
                        <li><i class="fa fa-map-marker"></i> 16 KM from Pari Chowk, Gretaer Noida.</li>
                    </ul>
                </div>
            </div>
		</div>
    
    </section>    <!-- ##### Location Properties Area End ##### -->
    
    <!-- ##### Contact Form Area Start ##### -->    
    <section class="south-contact-area section-padding-100-25" id="Register">
        <div class="container">
            <div class="row">
            	<div class="col-12 contact-heading" style="margin:0;">
                        <h2>Call-9899424270 or Register for Best Deal.</h2>
                        <p>Please fill in the following details. We will get back to you shortly.</p>
                    </div>
                <!-- Contact Form Area -->
                <div class="advanced-search-form" style="width:90%; margin:auto;">
                        <!-- Search Form -->
                        <form action="mail.php" name="enquiry" id="frmcontact"  method="post" onsubmit="return validateform(this);">
                            <div class="row">

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                    	<input type="text" class="form-control" name="name" value="" placeholder="Name">
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="email" value="" placeholder="Email">
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="phone" value="" placeholder="Phone Number">
                                    </div>
                                </div>

                                <div class="col-12 col-md-4 col-lg-3">
                                    <div class="form-group">
                                        <input type="text" class="form-control" name="message" value="" placeholder="Requirement ">
                                    </div>
                                </div>

                                <div class="col-12 d-flex justify-content-between align-items-end">
                                    <!-- More Filter -->
                                    <div class="more-filter">
                                        
                                    </div>
                                    <!-- Submit -->
                                    <div class="form-group mb-0">
                                        <button type="submit" name="submit" class="btn south-btn">I am Interested</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
            </div>
        </div>
    </section>
    <!-- ##### Contact Form Area End ##### -->

    <!-- ##### Model Form Start ##### -->
    <!-- Modal -->
	<!-- ##### Model Form Start ##### -->
    <!-- Modal -->
		<div class="modal fade popupsize" id="Enquire_Now_Popup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            	<img src="img/images/logo-sikka.jpeg" class="img-responsive modal-img">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></button>
                    <h4 class="modal-title" id="myModalLabel">BEST OFFER @ 9899424270</h4>
                </div>
                <div class="modal-body">

                    <form action="mail.php" method="post" onsubmit="return validateform(this)">
                        <div class="form-group">
                            <input type="text" name="name" id="qname2" placeholder="Your Name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="email" name="email" id="qemail2" placeholder="Email Id" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <input type="number" name="phone" id="qphone2" placeholder="Mobile Number" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <input type="hidden" name="message" id="qdesc2" placeholder="price list" value="Price List and Floor Plan" required>
                        </div>

                        <input type="submit" name="submit" value="SUBMIT" class="btn btn-primary btn-block">
                    </form>
                </div>
			</div>
        </div>
    </div>
	
    <script type="text/javascript">
        function isNumber(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        }
        function isNAME(evt) {
            evt = (evt) ? evt : window.event;
            var charCode = (evt.which) ? evt.which : evt.keyCode;
            if (charCode > 32 && (charCode < 65 || charCode > 90) && (charCode < 97 || charCode > 122)) {
                return false;
            }
            return true;
        }
    </script>    <!-- ##### Model Form End ##### -->    <!-- ##### Model Form End ##### -->

    

    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area section-padding-100-0 bg-img gradient-background-overlay" style="background-image: url(img/images/bg.jpeg);">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>About Us</h6>
                            </div>

                            <img src="img/images/sikka-logo.png" alt="sikka logo" title="sikka group" class="img-responsive">
                            <p>Sikka Group is the Most Trusted Real Estate Company in Delhi NCR. The Company has been developing residential project in Delhi, Noida, Greater Noida, Ghaziabad, Meerut & Dehradun.</p>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-5">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>Working Hours</h6>
                            </div>
                            <!-- Office Hours -->
                            <div class="weekly-office-hours">
                                <ul>
                                    <li class="d-flex align-items-center justify-content-between"><span>Saturday - Sunday</span> <span>9.30 AM - 7.30 PM</span></li>
                                    <li class="d-flex align-items-center justify-content-between"><span>Monday - Friday</span> <span>10.00 AM - 6.30 PM</span></li>
                                </ul>
                            </div>
                            <!-- Address -->
                            <div class="address">
                                <h6><i class="fa fa-volume-control-phone"></i> +91-9899424270</h6>
<h6><i class="fa fa-envelope"></i> info@sikkakaamyagreens.in</h6>
<h6><i class="fa fa-address-card"></i> Plot No. GH-02B, Sec-10 Greater Noida(W) (U.P.) 203207.</h6>                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-4">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>Useful Links</h6>
                            </div>
                            <!-- Nav -->
                            <ul class="useful-links-nav d-flex align-items-center">
                            	<li><a href="./">Home</a></li>
                                <li><a href="#" target="_blank">Blog</a></li>
                                <li><a href="specifications.php">Specifications</a></li>
                                <li><a href="location-map.php">Location Map</a></li>
                                <li><a href="site-map.php">Site Map</a></li>
                                <li><a href="floor-plan.php">Floor Plan</a></li>
                                <li><a href="price-list.php">Price List</a></li>
                                <li><a href="brochure.php">Brochure</a></li>
                                <li><a href="thank-you.php">Thank You</a></li>
                                <li><a href="our-address.php">Contact</a></li>
                                <li><a href="sitemap.xml">XML SITEMAP</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    

                </div>
            </div>
        </div>

        <!-- Copywrite Text -->
        <div class="copywrite-text d-flex align-items-center justify-content-center">
            <p><!-- Template Footer -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Disclaimer: This is not an official website. Images for representation purpose only.
<!-- Template Footer -->
        </div>
    </footer>    <!-- ##### Footer Area End ##### -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->

    <!-- Bootstrap js -->

    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <script src="js/classy-nav.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>


</body>
<link rel="stylesheet" type="text/css" href="./css-popup/font-awesome.css">
<link rel="stylesheet" type="text/css" href="./css-popup/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="./css-popup/jquery.fancybox.min.css">
<!---
<script type="text/javascript" src="./js-popup/bootstrap.js"></script>
--->
<script type="text/javascript" src="./js-popup/jquery.fancybox.min.js"></script>
<script type="text/javascript" src="./js-popup/latae.js"></script>

<script type="text/javascript" src="./js-popup/custom.js"></script>
<script type="text/javascript" src="./js-popup/jquery.min.js"></script>
</html>