<!DOCTYPE html>
<html lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title>Sikka Kaamya Greens Noida Extension | Possession Soon!</title>
<meta name="description" itemprop="description" content="Sikka Kaamya Greens offering 2BHK, 3BHK & 4BHK Specious Apartments for Sale in Noida Extension with modern amenities. Call-9899424270 or Register for Best Deal." />
<meta name="keywords" itemprop="keywords" content="sikka kaamya greens, sikka kaamya greens noida extension, sikka kaamya greens greater noida west, sikka kaamya greens floor plan, sikka kaamya greens site map, sikka kaamya greens price list, sikka kaamya greens location map, sikka kaamya greens brochure, sikka group" />
<link rel="canonical" href="https://www.sikkakaamyagreens.in/thank-you.php" />

<meta name="google-site-verification" content="ZNaOKd1zQusxwr9Kwj9CUwbCW4fVfIbfpc7IUstvquM" />
<meta name="revisit-after" content="1 days" />
<meta name="distribution" content="Global" />
<meta name="Language" content="English" />
<meta name="doc-type" content="Public" />
<meta name="robots" content="index, follow" />
<meta name="author" content="Sikka Kaamya Greens" />
<meta name="title" content="Sikka Kaamya Greens">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="category" content="buy, rent, sell, residential, commercial, brokers, dealers, pg, house, real estate agents, flats, apartments, house, plots, home, shop, office, complex, villa, lease, property delhi ncr, real estate, delhi/ncr, gurgaon, greater-noida, ghaziabad, lucknow" />
<meta name="alexa" content="100" /><meta name="googlebot" content="all, index, follow" /><meta name="YahooSeeker" content="all, index, follow" /><meta name="msnbot" content="all, index, follow" /><meta name="pagerank" content="10" /><meta name="serps" content="1, 2, 3, 10, 11, 12, 13, 20, ATF" /><meta name="relevance" content="high" />
<!-- Favicon  -->
<link rel="icon" href="img/images/favicon.png">
<!-- Style CSS -->
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap-theme.css">
<!-- ValidateForm bellow -->
<script type="text/javascript" src="js/validation.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<!--	control u,c & right click disable start	-->

<!--	control u,c & right click disable end	-->

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/62fa0dfa37898912e9630eb5/1gagcd7ol';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="south-load"></div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="h-100 d-md-flex justify-content-between align-items-center">
                <div class="email-address">
                    Welcome to Sikka Kaamya Greens Sector-10 Greater Noida(W).
                </div>
                <div class="phone-number d-flex">
                    <div class="icon">
                        <i class="fa fa-volume-control-phone"></i>
                    </div>
                    <div class="number">
                        <a href="tel:+91-9899424270">+91-9899424270</a>                    </div>
                </div>
            </div>
        </div>
        <!-- Main Header Area -->
        <div class="main-header-area" id="stickyHeader">
            <div class="classy-nav-container breakpoint-off">
                <!-- Classy Menu -->
                <nav class="classy-navbar justify-content-between" id="southNav">
					<!-- Logo -->
                    <a class="nav-brand" href="./"><img src="img/images/logo-sikka.jpeg" alt="sikka logo" title="sikka group" class="img-responsive" width="131px;"></a>
                    <!-- Navbar Toggler -->
                    <div class="classy-navbar-toggler">
                        <span class="navbarToggler"><span></span><span></span><span></span></span>
                    </div>

                    <!-- Menu -->
                    <div class="classy-menu">

                        <!-- close btn -->
                        <div class="classycloseIcon">
                            <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                        </div>

                        <!-- Nav Start -->
                        <div class="classynav">
                            <ul>
                                <li><a href="./">Home</a></li>
                                <li><a href="specifications.php">Specifications</a></li>
                                <li><a href="location-map.php">Location Map</a></li>
                                <li><a href="site-map.php">Site Map</a></li>
                                <li><a href="floor-plan.php">Floor Plan</a></li>
                                <li><a href="price-list.php">Price List</a></li>
                                <li><a href="brochure.php">Brochure</a></li>
                                <li><a href="our-address.php">Contact</a></li>
                            </ul>

                            <!-- Search Form -->
                           <!-- Search Button -->
                            
                        </div>
                        <!-- Nav End -->
                    </div>
                    <a class="nav-brand" href="./"><img src="img/images/sikka-kaamya-greens-logo.jpeg" alt="sikka kaamya greens logo" title="sikka kaamya greens greater noida west" class="img-responsive" width="131px;" style="margin-left:30px;"></a>
                </nav>
            </div>
        </div>    </header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Main Banner Start ##### -->
    <section section="container">
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <!-- Indicators -->
        
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
    
          <div class="item active">
            <img src="img/images/banner.jpeg" alt="banner" style="width:100%;">            <div class="centered">Thanks for Query</div>
          </div>
    
        </div>
    
        <!-- Left and right controls -->
      </div>
	</section>
    <!-- ##### Main Banner End ##### -->
	
    <!-- ##### Contact Info Start ##### -->
    <section class="south-contact-area section-padding-50">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="contact-heading">
                        <h6>Thanks for Query!</h6>
                        <p>Our property advisors will get in touch with you soon.</p>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-12 col-lg-4">
                    <div class="content-sidebar">
                        <!-- Office Hours -->
                        <div class="weekly-office-hours">
                            <ul>
                                <li class="d-flex align-items-center justify-content-between"><span>Saturday - Sunday</span> <span>09 AM - 7.00 PM</span></li>
                                    <li class="d-flex align-items-center justify-content-between"><span>Tuseday - Friday</span> <span>10 AM - 6.30 PM</span></li>
                                    <li class="d-flex align-items-center justify-content-between"><span>Monday</span> <span>Closed</span></li>
                            </ul>
                        </div>
                        <!-- Address -->
                        <div class="address mt-30">
                            <h6><i class="fa fa-volume-control-phone"></i> +91-9899424270</h6>
<h6><i class="fa fa-envelope"></i> info@sikkakaamyagreens.in</h6>
<h6><i class="fa fa-address-card"></i> Plot No. GH-02B, Sec-10 Greater Noida(W) (U.P.) 203207.</h6>                        </div>
                    </div>
                </div>

                <!-- Contact Form Area -->
                <div class="col-12 col-lg-8">
                    <div class="contact-form">
                        <form action="mail.php" name="enquiry" id="frmcontact"  method="post" onsubmit="return validateform(this);">
                            <div class="form-group">
                                <input type="text" class="form-control" name="name" value="" placeholder="Name">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="email" value="" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="phone" value="" placeholder="Phone Number">
                            </div>
                            <div class="form-group">
                            	<textarea class="form-control" name="message" id="message" cols="30" rows="10" placeholder="Your Message"></textarea>
                            </div>
                            <button type="submit" class="btn south-btn">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
            <!--Google Map Start -->
            <div class="row mt-30">
            	 <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14016.082909064377!2d77.4787369!3d28.5691403!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x7c4551accfcb80fd!2sSikka%20Kaamya%20Greens!5e0!3m2!1sen!2sin!4v1660363370924!5m2!1sen!2sin" width="100%" height="635" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
            <!--Google Map End -->
        </div>
    </section>
    <!-- ##### Contact Info End ##### -->

    

    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area section-padding-100-0 bg-img gradient-background-overlay" style="background-image: url(img/images/bg.jpeg);">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-3">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>About Us</h6>
                            </div>

                            <img src="img/images/sikka-logo.png" alt="sikka logo" title="sikka group" class="img-responsive">
                            <p>Sikka Group is the Most Trusted Real Estate Company in Delhi NCR. The Company has been developing residential project in Delhi, Noida, Greater Noida, Ghaziabad, Meerut & Dehradun.</p>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-5">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>Working Hours</h6>
                            </div>
                            <!-- Office Hours -->
                            <div class="weekly-office-hours">
                                <ul>
                                    <li class="d-flex align-items-center justify-content-between"><span>Saturday - Sunday</span> <span>9.30 AM - 7.30 PM</span></li>
                                    <li class="d-flex align-items-center justify-content-between"><span>Monday - Friday</span> <span>10.00 AM - 6.30 PM</span></li>
                                </ul>
                            </div>
                            <!-- Address -->
                            <div class="address">
                                <h6><i class="fa fa-volume-control-phone"></i> +91-9899424270</h6>
<h6><i class="fa fa-envelope"></i> info@sikkakaamyagreens.in</h6>
<h6><i class="fa fa-address-card"></i> Plot No. GH-02B, Sec-10 Greater Noida(W) (U.P.) 203207.</h6>                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-xl-4">
                        <div class="footer-widget-area mb-100">
                            <!-- Widget Title -->
                            <div class="widget-title">
                                <h6>Useful Links</h6>
                            </div>
                            <!-- Nav -->
                            <ul class="useful-links-nav d-flex align-items-center">
                            	<li><a href="./">Home</a></li>
                                <li><a href="#" target="_blank">Blog</a></li>
                                <li><a href="specifications.php">Specifications</a></li>
                                <li><a href="location-map.php">Location Map</a></li>
                                <li><a href="site-map.php">Site Map</a></li>
                                <li><a href="floor-plan.php">Floor Plan</a></li>
                                <li><a href="price-list.php">Price List</a></li>
                                <li><a href="brochure.php">Brochure</a></li>
                                <li><a href="thank-you.php">Thank You</a></li>
                                <li><a href="our-address.php">Contact</a></li>
                                <li><a href="sitemap.xml">XML SITEMAP</a></li>
                            </ul>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    

                </div>
            </div>
        </div>

        <!-- Copywrite Text -->
        <div class="copywrite-text d-flex align-items-center justify-content-center">
            <p><!-- Template Footer -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Disclaimer: This is not an official website. Images for representation purpose only.
<!-- Template Footer -->
        </div>
    </footer>    <!-- ##### Footer Area End ##### -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->

    <!-- Bootstrap js -->

    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <script src="js/classy-nav.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>
